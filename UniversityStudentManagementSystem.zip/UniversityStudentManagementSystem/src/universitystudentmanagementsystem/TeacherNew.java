/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitystudentmanagementsystem;
import java.sql.*;
import javax.swing.*;
/**
 *
 * @author helllord
 */
public class TeacherNew {
    Connection conn;
    public static Connection teachernewdb(){
        
    
         try{
            Class.forName("org.sqlite.JDBC");
            Connection conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\helllord\\Desktop\\java\\UniversityStudentManagementSystem\\AdminNew.sqlite");
            return conn;
        }catch(Exception e){
          JOptionPane.showMessageDialog(null,e);
          return null;
        }
    }
}
